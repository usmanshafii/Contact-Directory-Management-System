import java.io.File;
import java.io.IOException;
import java.util.Scanner;
import java.util.StringTokenizer;

public class MakeHashDirectory {
    File file;
    Directory directory;

    public void makeHash(String filepath) throws IOException {
            file = new File(filepath);
            Scanner sc = new Scanner(file);
            directory = new Directory(filepath);

            while (sc.hasNextLine()) {
                String line = sc.nextLine();
                StringTokenizer tokenizer = new StringTokenizer(line, " ");
                String FirstName = tokenizer.nextToken();
                String LastName = tokenizer.nextToken();
                String PhoneNumber = tokenizer.nextToken();
                String EmailAddress = tokenizer.nextToken();
                String Occupation = tokenizer.nextToken();

                directory.addContact(FirstName, LastName, PhoneNumber, EmailAddress, Occupation);
            }
        }
    }
