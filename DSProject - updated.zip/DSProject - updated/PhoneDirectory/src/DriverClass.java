import java.io.IOException;
import java.util.Scanner;

public class DriverClass {
    public static void main(String[] args) throws IOException {
        String filepath = "C:\\Users\\usman_pyywgw5\\Desktop\\PhoneDirectory\\IBAphonebook.txt";
        MakeHashDirectory hashDirectory = new MakeHashDirectory();
        hashDirectory.makeHash(filepath);
        Scanner sc = new Scanner(System.in);
        String choice;

        while (true) {
            mainMenu();
            choice = sc.nextLine();

            if (choice.equals("1")) {
                System.out.println("\nEnter First Name: ");
                String fname = sc.nextLine();

                System.out.println("\nEnter Last Name: ");
                String lname = sc.nextLine();

                System.out.println("\nEnter Contact Number: ");
                String number = sc.nextLine();

                System.out.println("\nEnter email: ");
                String email = sc.nextLine();

                System.out.println("\nEnter occupation: ");
                String occ = sc.nextLine();

                hashDirectory.directory.addContact(fname, lname, number, email, occ);
           //     hashDirectory.directory.updateFile();
            }

            if (choice.equals("2")) {
                hashDirectory.directory.Search();
            }

            if (choice.equals("3")) {
                hashDirectory.directory.deleteContact();
            }

            if (choice.equals("4")) {
                System.out.println("\nEnter the number of contact you want to update: ");
                String number = sc.nextLine();


                System.out.println("\nEnter old detail: ");
                String oldString = sc.nextLine();

                System.out.println("\nEnter new detail: ");
                String newString = sc.nextLine();

                hashDirectory.directory.updateContact(number,oldString,newString);
            }
            if(choice.equals("5")){
                hashDirectory.directory.printDirectory();
            }

            if (choice.equals("6")) {
                break;
            }
        }
    }

    public static void mainMenu() {
        System.out.println("---------------Main Menu---------------");
        System.out.println("\nPress 1 to add new Contact");
        System.out.println("\nPress 2 to search Contact");
        System.out.println("\nPress 3 to Delete Contact");
        System.out.println("\nPress 4 to Update Existing Contact");
        System.out.println("\nPress 5 print all Existing Contacts");
        System.out.println("\nPress 6 to Exit");
    }
}
