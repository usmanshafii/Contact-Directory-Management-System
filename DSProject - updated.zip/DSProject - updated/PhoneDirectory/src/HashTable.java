class HashNode{
    String fname, lname, number, email, occupation;

    public HashNode(String fname, String lname, String number, String email, String occupation) {
        this.fname = fname;
        this.lname = lname;
        this.number = number;
        this.email = email;
        this.occupation = occupation;
    }
}

public class HashTable{
    //good hash function implemented using linearprobing
        HashNode[] Table;

        int numofCollisions = 0;
        int numofOccupiedCells = 0;
        HashTable(int s){
            int size=s+(s/3);
            int newSize = getPrime(size);
            Table=new HashNode[newSize];
            for (int i = 0; i < Table.length; i++) {
                    Table[i] = null;
            }
        }
        private int getPrime(int n) {
            while(true) {
                if (isPrime(n)) return n;
                n++;
            }
        }
        private boolean isPrime(int n) {
            for (int i = 2; i <= n/2; i++) {
                if (n % i == 0) return false;
            }
            return true;
        }
        private int Hash(String s){
            //compute hash value by taking mod on key value and return remainder
           // int number = Math.abs(s.hashCode());
            int number = FoldingMethod(s);
            return number % Table.length;
        }
        private int Rehash(int key, int i){
            return (key+i)% Table.length;
        }

        public void delete(String str){
            int hashValue = Hash(str);
            int temp = hashValue;
            if(Table[hashValue]!=null && ( Table[hashValue].email.equalsIgnoreCase(str)||Table[hashValue].number.equalsIgnoreCase(str))) {
                Table[hashValue] = null;
                numofOccupiedCells--;
            }
            else{
                int i= 1;
                while(i<Table.length && Table[hashValue]!=null) {
                    hashValue = Rehash(hashValue, i);
                    if (Table[hashValue] != null && (Table[hashValue].email.equalsIgnoreCase(str) || Table[hashValue].number.equalsIgnoreCase(str))) {
                        Table[hashValue] = null;
                        numofOccupiedCells--;
                        break;
                    }
                    i++;
                }
                System.out.println("Contact does not exist");
            }
        }
        public void insert(String fname, String lname, String number, String email, String occupation){ // keep maintain 1/3 empty cells

            HashNode node = new HashNode(fname,lname,number,email,occupation);
            if((1.0 * numofOccupiedCells/Table.length) >= 0.7){
                int size = Table.length*2 + (Table.length*2)/3;
                int newSize = getPrime(size);
                HashNode[] temp = new HashNode[newSize];
                for (int i = 0; i < Table.length; i++) {
                    temp[i] = Table[i];
                }
                for (int i = Table.length; i < temp.length; i++) {
                    temp[i] = null;
                }
                Table = temp;
            }else{
                int hashValue = Hash(number);
                if(Table[hashValue]==null){
                    Table[hashValue] = node;
                    numofOccupiedCells++;
                }else{
                    int i= 1;
                    while(i<Table.length && Table[hashValue]!=null){
                        numofCollisions++;
                        hashValue = Rehash(hashValue,i);
                        if(Table[hashValue]==null){
                            Table[hashValue]=node;
                            numofOccupiedCells++;
                            break;}
                        i++;
                    }
                }
            }
        }
        public void update(String contact, String old,String latest){
            int hashValue = this.Hash(contact);
            if(Table[hashValue]!=null && ( Table[hashValue].number.equalsIgnoreCase(contact))) {
                if(Table[hashValue].email.equalsIgnoreCase(old)){
                    Table[hashValue].email = latest;
                }else if (Table[hashValue].occupation.equalsIgnoreCase(old)){
                    Table[hashValue].occupation = latest;
                }
            }
            else{
                int i= 1;
                while(i<Table.length && Table[hashValue]!=null){
                    hashValue = Rehash(hashValue,i);
                    if(Table[hashValue]!=null && ( Table[hashValue].number.equalsIgnoreCase(contact))) {
                        if (Table[hashValue].email.equalsIgnoreCase(old)) {
                            Table[hashValue].email = latest;
                        } else if (Table[hashValue].occupation.equalsIgnoreCase(old)) {
                            Table[hashValue].occupation = latest;
                        }
                        break;
                    }
                    i++;
                }
                System.out.println("No existing contact has this number");
            }
        }

        public HashNode search (String str) {
            int hashValue = this.Hash(str);
            if(Table[hashValue]!=null && (Table[hashValue].email.equalsIgnoreCase(str) || (Table[hashValue].fname.equalsIgnoreCase(str)&&Table[hashValue].lname.equalsIgnoreCase(str)) || Table[hashValue].occupation.equalsIgnoreCase(str)||Table[hashValue].number.equalsIgnoreCase(str))) {
                return Table[hashValue];
            }
            else{
                int i= 1;
                while(i<Table.length && Table[hashValue]!=null){
                    hashValue = Rehash(hashValue,i);
                    if(Table[hashValue]!=null && (Table[hashValue].email.equalsIgnoreCase(str)||Table[hashValue].fname.equalsIgnoreCase(str)||Table[hashValue].lname.equalsIgnoreCase(str)||Table[hashValue].occupation.equalsIgnoreCase(str)||Table[hashValue].number.equalsIgnoreCase(str)))
                        return Table[hashValue];
                    i++;
                }
                return null;
            }
        }

        public void printContactDetails(String str){
            HashNode temp = search(str);
            if(temp==null)
                System.out.println("Contact Not Found");
            else{
                System.out.println("Name: "+temp.fname+" "+temp.lname+"Contact: "+temp.number + " Occupation: "+temp.occupation+" Email: "+temp.email);
            }
        }

        public String toString(){
            String str="";
            for (int i = 0; i < Table.length; i++) {
                if(Table[i]!=null) {
                    str = str + "[" + i + "] " + "Name: " + Table[i].fname + " " + Table[i].lname + "Contact: " + Table[i].number + " Occupation: " + Table[i].occupation + " Email: " + Table[i].email + "\n";
                }
                }
            return str;
        }

        public int FoldingMethod(String s){
            if(s.length()<=3)
                return Integer.parseInt(s);
            return FoldingMethod(s.substring(0,s.length()/2)) + FoldingMethod(s.substring(s.length()/2 +1));
        }
    }
