import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class Directory {
        HashTable hashTable = new HashTable(100);
        Scanner sc = new Scanner(System.in);
        FileWriter fw;
        String path;

        public Directory(String Path) throws IOException {
            this.path = Path;
   //          this.fw = new FileWriter(Path,true);
        }

        public void addContact(String First, String Last, String number, String email, String occupation) throws IOException {
            hashTable.insert(First, Last, number, email, occupation);
        }

        public void Search() throws IOException {
            System.out.println("\nPlease enter Contact Number of the person you want to search");
            String Phone = sc.next();
            hashTable.printContactDetails(Phone);
        }

        public void updateContact(String contact,String oldString ,String newString) throws IOException {
            hashTable.update(contact,oldString,newString);

        //    updateFile();
        }

        public void deleteContact() throws IOException {
            System.out.println("Please Enter The Contact Number of the person you want to remove");
            String str = sc.next();

            hashTable.delete(str);
        //    updateFile();
        }
        public void printDirectory(){
            System.out.println(hashTable);
        }

//        public void updateFile() throws IOException {
//            this.fw = new FileWriter(this.path);
//            BufferedWriter bw = new BufferedWriter(this.fw);
//
//            bw.write(hashTable.toString());
//            bw.close();
//            this.fw.close();
//        }
    }
